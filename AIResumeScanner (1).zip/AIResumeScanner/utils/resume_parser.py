import PyPDF2
from docx import Document
import logging

logger = logging.getLogger(__name__)

def extract_text(file_path):
    """Extract text from PDF or DOCX files"""
    try:
        if file_path.endswith('.pdf'):
            return extract_from_pdf(file_path)
        elif file_path.endswith(('.docx', '.doc')):
            return extract_from_docx(file_path)
        return None
    except Exception as e:
        logger.error(f"Error extracting text: {str(e)}")
        return None

def extract_from_pdf(file_path):
    """Extract text from PDF file"""
    text = ""
    with open(file_path, 'rb') as file:
        pdf_reader = PyPDF2.PdfReader(file)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text.strip()

def extract_from_docx(file_path):
    """Extract text from DOCX file"""
    doc = Document(file_path)
    text = []
    for paragraph in doc.paragraphs:
        text.append(paragraph.text)
    return '\n'.join(text).strip()
