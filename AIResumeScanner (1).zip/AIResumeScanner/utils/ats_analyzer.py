import re
import logging

logger = logging.getLogger(__name__)

def analyze_ats_compatibility(text):
    """Analyze resume for ATS compatibility"""
    try:
        score = 100
        feedback = []

        # Check for common ATS issues
        checks = [
            (len(text.strip()) < 100, 
             "Resume content is too short", -20),
            
            (bool(re.search(r'[^\x00-\x7F]+', text)), 
             "Contains special characters that may not be ATS-friendly", -10),
            
            (bool(re.search(r'\.{3,}|_{3,}|\*{3,}', text)), 
             "Contains excessive punctuation or formatting", -5),
            
            (len(text.split()) < 200, 
             "Content might be too brief for proper ATS parsing", -15),
            
            (bool(re.search(r'<[^>]+>', text)), 
             "Contains HTML tags that may interfere with parsing", -10),
            
            (len(max(text.split('\n'), key=len, default='')) > 150,
             "Contains very long lines that might not parse well", -5)
        ]

        for condition, message, penalty in checks:
            if condition:
                score += penalty
                feedback.append(message)

        # Add positive feedback if no issues found
        if not feedback:
            feedback.append("Resume appears to be well-formatted for ATS systems")

        # Ensure score stays within 0-100 range
        score = max(0, min(100, score))

        return score, feedback

    except Exception as e:
        logger.error(f"Error analyzing ATS compatibility: {str(e)}")
        return 0, ["Error analyzing ATS compatibility"]
