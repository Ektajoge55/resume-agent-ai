import spacy
import logging

logger = logging.getLogger(__name__)

# Load the English model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    logger.error("Spacy model 'en_core_web_sm' not found")
    nlp = None

# Common technical skills and keywords
SKILL_PATTERNS = [
    "python", "javascript", "java", "c++", "ruby", "php", "swift",
    "react", "angular", "vue", "node.js", "django", "flask",
    "sql", "mongodb", "postgresql", "mysql", "redis",
    "aws", "azure", "gcp", "docker", "kubernetes",
    "machine learning", "artificial intelligence", "data science",
    "agile", "scrum", "devops", "ci/cd"
]

def extract_skills(text):
    """Extract skills from resume text"""
    if not nlp:
        return []
    
    try:
        # Convert text to lowercase for better matching
        text = text.lower()
        
        # Use spaCy for entity recognition
        doc = nlp(text)
        
        # Extract skills using pattern matching and NER
        skills = set()
        
        # Pattern matching for common skills
        for skill in SKILL_PATTERNS:
            if skill in text:
                skills.add(skill.title())
        
        # Extract technical terms and proper nouns that might be skills
        for ent in doc.ents:
            if ent.label_ in ["ORG", "PRODUCT"] and len(ent.text) > 2:
                skills.add(ent.text.title())
        
        return sorted(list(skills))
    except Exception as e:
        logger.error(f"Error extracting skills: {str(e)}")
        return []
