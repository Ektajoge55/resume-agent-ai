import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.utils import secure_filename
from utils.resume_parser import extract_text
from utils.skill_extractor import extract_skills
from utils.ats_analyzer import analyze_ats_compatibility

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# File upload configuration
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'doc'}
UPLOAD_FOLDER = '/tmp/uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze_resume():
    if 'resume' not in request.files:
        flash('No file uploaded', 'error')
        return redirect(url_for('index'))
    
    file = request.files['resume']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('index'))

    if not allowed_file(file.filename):
        flash('Invalid file type. Please upload PDF or DOC/DOCX files.', 'error')
        return redirect(url_for('index'))

    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)

        # Extract text from resume
        text = extract_text(filepath)
        if not text:
            flash('Could not extract text from the resume', 'error')
            return redirect(url_for('index'))

        # Extract skills
        skills = extract_skills(text)

        # Analyze ATS compatibility
        ats_score, ats_feedback = analyze_ats_compatibility(text)

        # Store results in session
        session['analysis_results'] = {
            'skills': skills,
            'ats_score': ats_score,
            'ats_feedback': ats_feedback
        }

        # Clean up
        os.remove(filepath)
        
        return render_template('results.html',
                             skills=skills,
                             ats_score=ats_score,
                             ats_feedback=ats_feedback)

    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        flash('An error occurred while processing the resume', 'error')
        return redirect(url_for('index'))

@app.errorhandler(404)
def not_found_error(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('index.html'), 500
